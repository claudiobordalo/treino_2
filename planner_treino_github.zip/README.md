# Planner de Treino – GitHub Pages / PWA
- Selecione 3d/4d/5d, edite exercícios, escolha técnicas (Tradicional/Drop/Rest‑Pause/Cluster).
- Adicione até 2 dias de Cardio (20–30min, Z2/Z3/Intervalado).
- Exportar CSV inclui técnica aplicada.
- Funciona offline ao instalar como PWA.

## Publicar
1) Repositório público no GitHub (ex.: `treino-pwa`).  
2) Envie todos os arquivos desta pasta.  
3) Settings → Pages → Deploy from branch (main / root).  
4) Abra: `https://SEU_USUARIO.github.io/SEU_REPO/`
